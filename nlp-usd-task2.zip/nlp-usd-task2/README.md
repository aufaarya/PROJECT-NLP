# Global Geopolitical Event Prediction — Impact on USD Exchange Rates
## Task 2: Pipeline Proposal & Baseline Experimentation

Hypothesis: global geopolitical news (NYT Archive API) helps predict next-day moves of the
US Dollar (FRED `DTWEXBGS`, Nominal Broad U.S. Dollar Index).

```
data/
  raw/          Task 1 outputs (USD series, daily category counts, collection log)
  processed/    train.csv, val.csv, test.csv (strict chronological 70/15/15), full_features.csv
src/
  config.py       paths, lexicon, windows, split ratios
  data_prep.py    trading-day alignment, weekend-news bucketing, targets, chronological split
  features.py     market features, lexicon volume/mix/shock features, VADER + TF-IDF/LSA text features
  models.py       ARIMA (baseline), ARIMAX (combined), LogReg/GBM with validation tuning
  evaluate.py     RMSE/MAE/DirAcc, Accuracy/Macro-F1/MCC/AUC, binomial test
  run_pipeline.py end-to-end run
notebook/
  task2_eda_and_baselines.ipynb   EDA + experiment results (executed)
results/          metrics_val.csv, metrics_test.csv, predictions_test.csv, run_summary.json, ...
reports/          Task2_Report.pdf, figures/, scripts that regenerate them
```

### Run
```bash
pip install -r requirements.txt
python -m src.run_pipeline          # builds splits + trains + evaluates -> data/processed, results/
python reports/make_diagram.py      # pipeline diagram
python reports/make_report.py       # PDF report (reads results/)
```

### Task formulation (short)
* **Target:** direction of the next trading day's log return, `UP(t+1) = 1[ln P(t+1)/P(t) > 0]`
  (primary, classification) and the return itself (secondary, regression).
* **Split:** oldest 70% train / next 15% validation / newest 15% test, no shuffling.
* **Metrics:** Accuracy, Macro-F1, MCC, ROC-AUC, binomial test vs 50%; RMSE/MAE (bp) vs random walk.

### Important change vs. Task 1
Task 1's daily table was on a calendar grid with the USD index forward-filled, so 31.5% of rows
had a 0% "next-day change" labelled DOWN (only 33.6% UP), which made "always DOWN" look like
66% accuracy. Task 2 works on trading days only and adds weekend/holiday news to the next
trading day.

### Adding the text features
Copy `nyt_geopolitical_articles_clean.csv` (Task 1 notebook, section 2) into `data/raw/` and
re-run the pipeline: a third feature set `market+news+text` (VADER tone + TF-IDF/LSA topics,
fit on the training period only) is added automatically.
